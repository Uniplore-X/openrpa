import glob
import os
import subprocess
import sys
import traceback

# op_type = sys.argv[1] if len(sys.argv) > 1 else ''

python_dir = os.path.dirname(sys.executable)
current_dir = os.path.dirname(os.path.abspath(__file__))

# 安装pip模块
pip_path = os.path.join(current_dir, "install/pip.pyz")

lib_files = glob.glob(f"{current_dir}/install/*")
for lib in lib_files:
    if lib.endswith('.gitkeep') or lib.endswith('pip.pyz'):
        continue
    try:
        subprocess.check_call([sys.executable, pip_path, "install", "--no-warn-script-location",
                               "--no-deps", "--no-index", lib])
    except:
        traceback.print_stack()

pip_path = os.path.join(python_dir, "Scripts/pip.exe")
python_path = os.path.join(python_dir, "python.exe")

lib_files = glob.glob(f"{current_dir}/tools/*") + \
            glob.glob(f"{current_dir}/selenium/*") + glob.glob(f"{current_dir}/uniplore/*") + \
            glob.glob(f"{current_dir}/tools2/*")

for lib in lib_files:
    if lib.endswith('.gitkeep'):
        continue
    try:
        subprocess.check_call(
            [pip_path, "install", "--no-deps", "--no-index", lib])
    except:
        traceback.print_stack()

# path = os.environ.get('PATH', '')
# os.environ['PATH'] = python_dir + os.pathsep + os.path.join(python_dir, 'Scripts') + os.pathsep + path
# os.environ['PYTHONHOME'] = python_dir
#
# lib_files2 = glob.glob(f"{current_dir}/tools2/*")
# for lib in lib_files2:
#     if lib.endswith('.gitkeep'):
#         continue
#     try:
#         args = [pip_path, "install", "--no-index", f"--find-links={os.path.join(current_dir, 'tools2')}", lib]
#         subprocess.check_call(args)
#     except:
#         traceback.print_stack()

# 安装tar.gz模块
# if tar_gz_libs:
#     temp_dir = os.path.join(tempfile.gettempdir(), 'uniplore_rpatest_libs')
#     if os.path.exists(temp_dir):
#         try:
#             shutil.rmtree(temp_dir)
#         except:
#             traceback.print_stack()
#     for gz_lib in tar_gz_libs:
#         try:
#             print(f"解压：{gz_lib}")
#             print(f"\t到：{temp_dir}")
#             name = os.path.basename(gz_lib)[0:-7]
#
#             with tarfile.open(gz_lib, 'r:gz') as tar:
#                 tar.extractall(path=temp_dir)
#             setup_file = os.path.join(temp_dir, name, 'setup.py')
#             with open(setup_file, 'r') as file:
#                 setup_content = file.read()
#             # 替换install_requires，忽略依赖（--no-deps参数无效）
#             new_setup_content = re.sub(r'install_requires\s*=\s*\[([^\[\]]*)]', 'install_requires=[]',
#                                        setup_content)
#             with open(setup_file, 'w') as file:
#                 file.write(new_setup_content)
#
#             subprocess.check_call(
#                 [python_path, setup_file, "install"])  # '--no-deps'
#         except:
#             traceback.print_stack()
