import os
import glob
import sys
import subprocess

python_dir = os.path.dirname(sys.executable)
current_dir = os.path.dirname(os.path.abspath(__file__))

# 安装pip模块
pip_path = os.path.join(current_dir, "install/pip.pyz")
subprocess.check_call([sys.executable, pip_path, "install", "--no-warn-script-location", "--no-deps", "--no-index", "install/setuptools-68.0.0-py3-none-any.whl"])
subprocess.check_call([sys.executable, pip_path, "install", "--no-warn-script-location", "--no-deps", "--no-index", "install/pip-23.2.1-py3-none-any.whl"])

pip_path = os.path.join(python_dir, "Scripts/pip")

lib_files = glob.glob(f"{current_dir}/tools/*") + glob.glob(f"{current_dir}/selenium/*") + glob.glob(f"{current_dir}/uniplore/*")
            
for lib in lib_files:
    subprocess.check_call([pip_path, "install", "--no-warn-script-location", "--no-index", "--force-reinstall", "--no-deps", lib])
