## pip仅下载不安装命令
```shell
pip download -d ./my-libs/ -r requirement.txt
pip download -d ./my-libs/ lxml
pip download -d ./my-libs/ lxml==4.9.2
```