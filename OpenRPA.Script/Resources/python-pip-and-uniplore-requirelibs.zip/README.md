## pip仅下载不安装命令
```shell
pip download -d ./my-libs/ -r requirement.txt
pip download -d ./my-libs/ lxml
pip download -d ./my-libs/ lxml==4.9.2
```

## 目录说明

### install
手动下载一下文件：
- `pip.pyz` 用于安装pip
- `pip-x.x.x-py3-none-any.whl`
- `setuptools-x.x.x-py3-none-any.whl`

### selenium
selenium及其依赖包
```cmd
C:\Users\uniplore-x\AppData\Local\python-3.11.0-embed-amd64\python.exe .\install\pip.pyz download -d ./selenium/ selenium
```

### tools
其他工具包

- 进程管理
```cmd
C:\Users\uniplore-x\AppData\Local\python-3.11.0-embed-amd64\python.exe .\install\pip.pyz download -d ./tools/ psutil
```

- windows模拟
```cmd
C:\Users\uniplore-x\AppData\Local\python-3.11.0-embed-amd64\python.exe .\install\pip.pyz download -d ./tools/ pywinauto
```

- 截图
```cmd
C:\Users\uniplore-x\AppData\Local\python-3.11.0-embed-amd64\python.exe .\install\pip.pyz download -d ./tools/ pillow
```

### uniplore
uniplore内部模块
